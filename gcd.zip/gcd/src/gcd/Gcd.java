/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcd;

/**
 *
 * @author paulhinterberger
 */
public class Gcd {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int gcd1 = gcdPrimeFactors(1989, 867);
        int gcd2 = gcdEucledian(1989, 867);
        System.out.print(gcd1);
        System.out.print("\n");
        System.out.print(gcd2);
        System.out.print("\n");
    }
    static int gcdPrimeFactors(int a, int b){
        if(a % b != 0){
            return gcdPrimeFactors(b, a % b);
        }
        return b;
        /*
        int gcd1 = a;
        int gcd2 = b;
        int gcd3;
        while(gcd1 % gcd2 != 0){
            gcd3 = gcd1 % gcd2;
            gcd1 = gcd2;
            gcd2 = gcd3;
        }
        return gcd2;
        */
    }
    static int gcdEucledian(int a, int b){
        int gcd = 1;
        for(int i = 1; i <= a && i <= b; ++i)
        {
            if(a % i==0 && b % i==0){
                gcd = i;
            }
        }
        return gcd;
    }   
}
